package review_dao;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.sql.DataSource;
import vo.ReviewBean;

public class ReviewDAO {

	DataSource ds;
	Connection con;
	private static ReviewDAO ReviewDAO;

	private ReviewDAO() {
		// TODO Auto-generated constructor stub
	}

	public static ReviewDAO getInstance(){
		if(ReviewDAO == null){
			ReviewDAO = new ReviewDAO();
		}
		return ReviewDAO;
	}

	public void setConnection(Connection con){
		this.con = con;
	}

	//占쏙옙占쏙옙 占쏙옙占쏙옙 占쏙옙占싹깍옙.
	public int selectListCount() {
         System.out.println("DAO占쏙옙 selectlistcount 占쌜듸옙 ");
		int listCount= 0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			System.out.println("getConnection");
			pstmt=con.prepareStatement("select count(*) from board");
			rs = pstmt.executeQuery();

			if(rs.next()){
				listCount=rs.getInt(1);
			}
		}catch(Exception ex){

		}finally{
			close(rs);
			close(pstmt);
		}

		return listCount;

	}

	//占쏙옙 占쏙옙占� 占쏙옙占쏙옙.	
	public ArrayList<ReviewBean> selectArticleList(int page,int limit){
        
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_list_sql="select * from board order by ref desc,seq asc limit ?,10";
		ArrayList<ReviewBean> articleList = new ArrayList<ReviewBean>();
		ReviewBean board = null;
		int startrow=(page-1)*10; 	
	
		try{
			pstmt = con.prepareStatement(board_list_sql);
		pstmt.setInt(1, startrow);
			rs = pstmt.executeQuery();
            
			while(rs.next()){
				
				board = new ReviewBean();
				board.setRnum(rs.getInt("rnum"));
				board.setRnick(rs.getString("rnick"));
				board.setRtitle(rs.getString("rtitle"));
				board.setRcontent(rs.getString("rcontent"));
				board.setRfile(rs.getString("rfile"));
				board.setLocation(rs.getString("location"));
				board.setRef(rs.getInt("ref"));
	            board.setLev(rs.getInt("lev"));
				board.setSeq(rs.getInt("seq"));
				board.setReadcount(rs.getInt("readcount"));
				board.setDate(rs.getDate("date"));
				articleList.add(board);
			}
			
			

		}catch(Exception ex){
			System.out.println(ex);
		}finally{
			close(rs);
			close(pstmt);
		}

		return articleList;

	}
	
public ArrayList<ReviewBean> selectTitleList(ReviewBean reviewbean){
        System.out.println("selectTtitleList 메소드 작동");
        System.out.println(reviewbean.getKeyword());
        String key = reviewbean.getKeyword();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_list_sql="select * from board where rtitle = ?";
		ArrayList<ReviewBean> articleList = new ArrayList<ReviewBean>();
		ReviewBean board = null;	
		
		try{
			pstmt = con.prepareStatement(board_list_sql);
			pstmt.setString(1,key);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				System.out.println(rs.getString("rtitle"));
				board = new ReviewBean();
				board.setRnum(rs.getInt("rnum"));
				board.setRnick(rs.getString("rnick"));
				board.setRtitle(rs.getString("rtitle"));
				board.setRcontent(rs.getString("rcontent"));
				board.setRfile(rs.getString("rfile"));
				board.setLocation(rs.getString("location"));
				board.setRef(rs.getInt("ref"));
	            board.setLev(rs.getInt("lev"));
				board.setSeq(rs.getInt("seq"));
				board.setReadcount(rs.getInt("readcount"));
				board.setDate(rs.getDate("date"));
				articleList.add(board);
			}
			
			

		}catch(Exception ex){
			System.out.println(ex);
		}finally{
			close(rs);
			close(pstmt);
		}

		return articleList;

	}

public ArrayList<ReviewBean> selectIdList(ReviewBean reviewbean){
	 String key = reviewbean.getKeyword();
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String board_list_sql="select * from board where rnick= ?";
	ArrayList<ReviewBean> articleList = new ArrayList<ReviewBean>();
	ReviewBean board = null;
	

	try{
		pstmt = con.prepareStatement(board_list_sql);
		pstmt.setString(1,key);
		rs = pstmt.executeQuery();
        
		while(rs.next()){
			
			board = new ReviewBean();
			board.setRnum(rs.getInt("rnum"));
			board.setRnick(rs.getString("rnick"));
			board.setRtitle(rs.getString("rtitle"));
			board.setRcontent(rs.getString("rcontent"));
			board.setRfile(rs.getString("rfile"));
			board.setLocation(rs.getString("location"));
			board.setRef(rs.getInt("ref"));
            board.setLev(rs.getInt("lev"));
			board.setSeq(rs.getInt("seq"));
			board.setReadcount(rs.getInt("readcount"));
			board.setDate(rs.getDate("date"));
			articleList.add(board);
		}
		
		

	}catch(Exception ex){
		System.out.println(ex);
	}finally{
		close(rs);
		close(pstmt);
	}

	return articleList;

}

	//占쏙옙 占쏙옙占쏙옙 占쏙옙占쏙옙.
	public ReviewBean selectArticle(int board_num){
       
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ReviewBean boardBean = null;

		try{
			pstmt = con.prepareStatement(
					"select * from board where rnum = ?");
			pstmt.setInt(1, board_num);
			rs= pstmt.executeQuery();
			if(rs.next()){
				boardBean = new ReviewBean();
				boardBean.setRnum(rs.getInt("rnum"));
				boardBean.setRnick(rs.getString("rnick"));
				boardBean.setRtitle(rs.getString("rtitle"));
				boardBean.setRcontent(rs.getString("rcontent"));
				boardBean.setRfile(rs.getString("rfile"));
				boardBean.setLocation(rs.getString("location"));
				boardBean.setRef(rs.getInt("ref"));
				boardBean.setLev(rs.getInt("lev"));
				boardBean.setSeq(rs.getInt("seq"));
				boardBean.setReadcount(rs.getInt("readcount"));
				boardBean.setDate(rs.getDate("date"));
			}
		}catch(Exception ex){
		}finally{
			close(rs);
			close(pstmt);
		}

		return boardBean;

	}

	//占쏙옙 占쏙옙占�.
	public int insertArticle(ReviewBean article){
        System.out.println("2"+article.getLocation());
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int num =0;
		String sql="";
		int insertCount=0;

		try{
			pstmt=con.prepareStatement("select max(rnum) from board");
			rs = pstmt.executeQuery();
		
			if(rs.next())
				num =rs.getInt(1)+1;
			else
				num=1;

			sql="insert into board (rnum,rnick,rpass,rtitle,";
			sql+="rcontent, rfile, ref,"+
					"lev,seq,readcount,"+
					"date,location) values(?,?,?,?,?,?,?,?,?,?,now(),?)";
			System.out.println("dfsdf");
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, article.getRnick());
			pstmt.setString(3, article.getRpass());
			pstmt.setString(4, article.getRtitle());
			pstmt.setString(5, article.getRcontent());
			pstmt.setString(6, article.getRfile());
			pstmt.setInt(7, num);
			pstmt.setInt(8, 0);
			pstmt.setInt(9, 0);
			pstmt.setInt(10, 0);
			pstmt.setString(11, article.getLocation());

			insertCount=pstmt.executeUpdate();

		}catch(Exception ex){
			System.out.println(ex);
		}finally{
			close(rs);
			close(pstmt);
		}

		return insertCount;

	}

	//占쏙옙 占썰변.
	public int insertReplyArticle(ReviewBean article){

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_max_sql="select max(rnum) from board";
		String sql="";
		int num=0;
		int insertCount=0;
		int re_ref=article.getRef();
		int re_lev=article.getLev();
		int re_seq=article.getSeq();

		try{
		
			pstmt=con.prepareStatement(board_max_sql);
			rs = pstmt.executeQuery();
			if(rs.next())num =rs.getInt(1)+1;
			else num=1;
			sql="update board set seq=seq+1 where ref=? ";
			sql+="and seq>?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,re_ref);
			pstmt.setInt(2,re_seq);
			int updateCount=pstmt.executeUpdate();

			if(updateCount > 0){
				commit(con);
			}

			re_seq = re_seq + 1;
			re_lev = re_lev+1;
			sql="insert into board (rnum,rnick,rpass,rtitle,";
			sql+="rcontent,ref,lev,seq,";
			sql+="readcount,date,location) values(?,?,?,?,?,?,?,?,?,now(),?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, article.getRnick());
			pstmt.setString(3, article.getRpass());
			pstmt.setString(4, article.getRtitle());
			pstmt.setString(5, article.getRcontent());
			pstmt.setInt(6, re_ref);
			pstmt.setInt(7, re_lev);
			pstmt.setInt(8, re_seq);
			pstmt.setInt(9, 0);
			pstmt.setString(10, article.getLocation());
			insertCount = pstmt.executeUpdate();
		}catch(SQLException ex){
			System.out.println(ex);
		}finally{
			close(rs);
			close(pstmt);
		}

		return insertCount;

	}

	//占쏙옙 占쏙옙占쏙옙.
	public int updateArticle(ReviewBean article){

		int updateCount = 0;
		PreparedStatement pstmt = null;
		String sql="update board set rtitle=?,rcontent=?,location =? where rnum=?";

		try{
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, article.getRtitle());
			pstmt.setString(2, article.getRcontent());
			pstmt.setString(2, article.getLocation());
			pstmt.setInt(3, article.getRnum());
			updateCount = pstmt.executeUpdate();
		}catch(Exception ex){
			System.out.println(ex);
		}finally{
			close(pstmt);
		}

		return updateCount;

	}

	//占쏙옙 占쏙옙占쏙옙.
	public int deleteArticle(int board_num){

		PreparedStatement pstmt = null;
		String board_delete_sql="delete from board where rnum=?";
		int deleteCount=0;

		try{
			pstmt=con.prepareStatement(board_delete_sql);
			pstmt.setInt(1, board_num);
			deleteCount=pstmt.executeUpdate();
		}catch(Exception ex){
		}	finally{
			close(pstmt);
		}

		return deleteCount;

	}

	//占쏙옙회占쏙옙 占쏙옙占쏙옙占쏙옙트.
	public int updateReadCount(int board_num){
       
           
		PreparedStatement pstmt = null;
		int updateCount = 0;
		String sql="update board set readcount = "+
				"readcount+1 where rnum = "+board_num;

		try{
			pstmt=con.prepareStatement(sql);
			updateCount = pstmt.executeUpdate();
		}catch(SQLException ex){
		}
		finally{
			close(pstmt);

		}

		return updateCount;

	}

	//占쌜억옙占쏙옙占쏙옙占쏙옙 확占쏙옙.
	public boolean isArticleBoardWriter(int board_num,String pass){
    
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_sql="select * from board where rnum=?";
		boolean isWriter = false;

		try{
			pstmt=con.prepareStatement(board_sql);
			pstmt.setInt(1, board_num);
			rs=pstmt.executeQuery();
			rs.next();

			if(pass.equals(rs.getString("rpass"))){
				isWriter = true;
			}
		}catch(SQLException ex){
			System.out.println(ex);
		}
		finally{
			close(pstmt);
		}

		return isWriter;

	}
	

}
