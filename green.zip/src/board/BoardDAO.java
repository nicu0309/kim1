package board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import board.BoardDTO;

public class BoardDAO {
	private Connection conn;
	private ResultSet rs;

	public BoardDAO() {
		System.out.println("占쎈탵�뜮袁⑸염野껓옙 占쎄쉐�⑨옙");
		try {
			String dbURL = "jdbc:mysql://localhost/gpteam?useSSL=false&useUnicode=true&characterEncoding=utf8";
			String dbID = "root";
			String dbPassword = "nicu0309";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public String getDate() {

		String SQL = "SELECT NOW()";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				System.out.println(rs.getString(1));
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

//-----------------------------占쎈쐻占쎈셾占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲 占쎈쐻占쎈짗占쎌굲占쎌깈 占쎈쐻占쎈뻻筌뚭쑴�굲占쎈쐻占쎈솂占쎈솇占쎌굲 占쎈쐻占쎈솙占쎈섣占쎌굲------------------------------------------------------------------------------------
	public int getNext() {
		String SQL = "SELECT number FROM board ORDER BY number DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if (rs.next()) {

				return rs.getInt(1) + 1;
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

//---------------------------------占쎈쐻占쎈솙占쎈닰占쎌굲占쎈쐻占쎈짗占쎌굲 占쎈쐻占쎈셾占쎈뻻繹먮씮�굲 占쎈쐻占쎈짗占쎌굲占쎈쐻�뜝占� 占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈뼣占쎈솇占쎌굲 占쎈쐻占쎈솙占쎈섣占쎌굲----------------------------------------------------------------------------
	public int write(String title, String nic, String content, String locaition) {
		String SQL = "insert into board values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, title);
			pstmt.setString(3, nic);
			pstmt.setString(4, locaition);
			pstmt.setString(5, getDate());
			pstmt.setString(6, content);
			pstmt.setInt(7, 1);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
//----------------------------------占쎈쐻占쎈셾占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲 占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲 占쎈쐻占쏙옙筌뚭쑴�굲占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲-----------------------------------------------------------

	public ArrayList<BoardDTO> getList(int pageNumber) {

		String SQL = "SELECT * from board where number < ? and available = 1 order by number DESC LIMIT 10";
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				BoardDTO bbs = new BoardDTO();
				bbs.setNumber(rs.getInt(1));
				bbs.setTitle(rs.getString(2));
				bbs.setId(rs.getString(3));
				bbs.setLocation(rs.getString(4));
				bbs.setDate(rs.getString(5));
				bbs.setContent(rs.getString(6));
				bbs.setAvailable(rs.getInt(7));
				list.add(bbs);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}
//---------------------- 占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲 占쎈쐻占쎈뼓占쎈쿈占쎌굲 占쎈쐻占쎈솭占쎈꺖占쎈쿈占쎌굲----------------------------------------------------------------------

	public BoardDTO getDTO(int number) {
		String SQL = "SELECT * from board where number = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, number);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				BoardDTO bbs = new BoardDTO();
				bbs.setNumber(rs.getInt(1));
				bbs.setTitle(rs.getString(2));
				bbs.setId(rs.getString(3));
				bbs.setLocation(rs.getString(4));
				bbs.setDate(rs.getString(5));
				bbs.setContent(rs.getString(6));
				bbs.setAvailable(rs.getInt(7));
				return bbs;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

//===================占쎈쐻占쎈셾占쎈뻻繹먮씮�굲 占쎈쐻占쎈짗占쎌굲占쎈쐻占쎈짗占쎌굲============================================
	public int update(int number, String title, String content, String location) {
		System.out.println(number + title + content + location);
		String SQL = "update board set title=?,content = ?,location = ? where number =?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setString(3, location);
			pstmt.setInt(4, number);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return -1;
	}

	public int delete(int number) {
		String SQL = "update board set available= 0 where number =?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, number);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public ArrayList<BoardDTO> tsearchList(BoardDTO dto) {

		String SQL = "SELECT * from board where title='" + dto.getKeyword() + " ' ";
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				BoardDTO bbs = new BoardDTO();
				bbs.setNumber(rs.getInt(1));
				bbs.setTitle(rs.getString(2));
				bbs.setId(rs.getString(3));
				bbs.setLocation(rs.getString(4));
				bbs.setDate(rs.getString(5));
				bbs.setContent(rs.getString(6));
				bbs.setAvailable(rs.getInt(7));
				list.add(bbs);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}
	public ArrayList<BoardDTO> wsearchList(BoardDTO dto) {

		String SQL = "SELECT * from board where id like '%"+dto.getKeyword()+"%'";
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				BoardDTO bbs = new BoardDTO();
				bbs.setNumber(rs.getInt(1));
				bbs.setTitle(rs.getString(2));
				bbs.setId(rs.getString(3));
				bbs.setLocation(rs.getString(4));
				bbs.setDate(rs.getString(5));
				bbs.setContent(rs.getString(6));
				bbs.setAvailable(rs.getInt(7));
				list.add(bbs);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}
}