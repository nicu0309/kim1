package review_action;

import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import review_svc.ReviewReplyProService;
import vo.ActionForward;
import vo.ReviewBean;
import action.Action;

public class ReviewReplyProAction implements Action {
	
	 public ActionForward execute(HttpServletRequest request,HttpServletResponse response) 
	 throws Exception{
	         
		 	ActionForward forward = null;
		    String nowPage = request.getParameter("page");
		    ReviewBean article = new ReviewBean();  		
		 	article.setRnum(Integer.parseInt(request.getParameter("rnum")));
		 	article.setLocation(request.getParameter("location"));
		 	article.setRnick(request.getParameter("rnick"));
		 	article.setRpass(request.getParameter("rpass"));
		 	article.setRtitle(request.getParameter("rtitle"));
		 	article.setRcontent(request.getParameter("rcontent"));
		 	article.setRef(Integer.parseInt(request.getParameter("ref")));
		 	article.setLev(Integer.parseInt(request.getParameter("lev")));
		 	article.setSeq(Integer.parseInt(request.getParameter("seq")));	   		
		 	ReviewReplyProService boardReplyProService = new ReviewReplyProService();
		 	
		 	boolean isReplySuccess = boardReplyProService.replyArticle(article);
		 	
	   		if(isReplySuccess){
	   			System.out.println("isReplySuccess �۵�");
	   			forward = new ActionForward();
	   			forward.setRedirect(true);
	   			forward.setPath("reviewList.bo?page=" + nowPage);
	   		}
	   		else{
	   			response.setContentType("text/html;charset=UTF-8");
	   			PrintWriter out = response.getWriter();
	   			out.println("<script>");
	   			out.println("alert('�������')");
	   			out.println("history.back()");
	   			out.println("</script>");
	   		}
	   		
	   		return forward;
	   		
	}  	
	 
}