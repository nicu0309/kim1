package board;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import board.BoardDTO;

public class BoardDAO {
	private Connection conn;
	private ResultSet rs;
	PreparedStatement pstmt;
   
	public BoardDAO() {
		System.out.println("디비연결 성공");
		try {
			String dbURL = "jdbc:mysql://localhost/gpteam?useSSL=false&useUnicode=true&characterEncoding=utf8";
			String dbID = "root";
			String dbPassword = "nicu0309";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	void m3() {// 닫아주는 작업을 하는 메소드
		if (pstmt != null)
			try {
				pstmt.close();// 에스큐엘을 연결시켜주는 작업을 중단시키겠다.
			} catch (Exception e) {

			}

		if (conn != null)
			try {
				conn.close();
			} catch (Exception e) {

			}

	}
	
	public String getDate() { 
		
		String SQL= "SELECT NOW()";
		try {
	    pstmt = conn.prepareStatement(SQL);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			System.out.println(rs.getString(1));
			return rs.getString(1); 
		}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			m3();
		}
		return "";
	}
//-----------------------------占쌉쏙옙占쏙옙 占쏙옙호 占시뤄옙占쌍댐옙 占쌜억옙------------------------------------------------------------------------------------
public int getNext() { 
		String SQL= "SELECT number FROM board ORDER BY number DESC";
		try {
		pstmt = conn.prepareStatement(SQL); 
		rs = pstmt.executeQuery();
		if(rs.next()) {
		
			return rs.getInt(1)+1;  
		}
	   return 1; 
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			m3();
		}
		return -1;
	}
//---------------------------------占쌜쇽옙占쏙옙 占쌉시깍옙 占쏙옙占� 占쏙옙占쏙옙占싹댐옙 占쌜억옙----------------------------------------------------------------------------
public int write(String title,String nic,String content,String locaition,String filename) { 
	String SQL= "insert into board values(?,?,?,?,?,?,?,?)";
	try {
  pstmt = conn.prepareStatement(SQL);
	pstmt.setInt(1, getNext()); 
	pstmt.setString(2, title);
	pstmt.setString(3, nic);
	pstmt.setString(4, locaition);
	pstmt.setString(5, getDate());
	pstmt.setString(6, content);
	pstmt.setInt(7, 1);	
	pstmt.setString(8, filename);
     return pstmt.executeUpdate(); 
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		m3();
	}
	return -1; 
}
//----------------------------------占쌉쏙옙占쏙옙 占쏙옙占쏙옙 占쌀뤄옙占쏙옙占쏙옙-----------------------------------------------------------

public ArrayList<BoardDTO> getList(int pageNumber){

	String SQL= "SELECT * from board where number < ? and available = 1 order by number DESC LIMIT 10"; 
	ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
	
	try {
	pstmt = conn.prepareStatement(SQL); 

	pstmt.setInt(1, getNext() - (pageNumber-1)*10); 

	rs = pstmt.executeQuery();

	while(rs.next()) {

		BoardDTO bbs = new BoardDTO();
		bbs.setNumber(rs.getInt(1));
		bbs.setTitle(rs.getString(2));
		bbs.setId(rs.getString(3));
		bbs.setLocation(rs.getString(4));		
		bbs.setDate(rs.getString(5));
		bbs.setContent(rs.getString(6));
		bbs.setAvailable(rs.getInt(7));
		bbs.setFilename(rs.getString(8));
		list.add(bbs);
		
		
		
	}
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		m3();
	}
	return list;
	
}
//---------------------- 占쏙옙占쏙옙占쏙옙 占싱듸옙 占쌨소듸옙----------------------------------------------------------------------

public BoardDTO  getDTO(int number) {
	String SQL= "SELECT * from board where number = ?";
	
	try {
	pstmt = conn.prepareStatement(SQL); 
	pstmt.setInt(1, number); 
	rs = pstmt.executeQuery();
       if(rs.next()) {
    	BoardDTO bbs = new BoardDTO();
   		bbs.setNumber(rs.getInt(1));
   		bbs.setTitle(rs.getString(2));
   		bbs.setId(rs.getString(3));
   		bbs.setLocation(rs.getString(4));
   		bbs.setDate(rs.getString(5));
   		bbs.setContent(rs.getString(6));
   		bbs.setAvailable(rs.getInt(7));
   		bbs.setFilename(rs.getString(8));
    	  
   		return bbs ;
       }
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		m3();
	}
	return null ;
	
}
//===================占쌉시깍옙 占쏙옙占쏙옙============================================
public int update(int number,String title, String content,String location,String filename ) {
	String SQL="";
	if(filename == null) {
		SQL= "update board set title=?,content = ?,location = ? where number =?";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,title);
			pstmt.setString(2,content);
			pstmt.setString(3,location);
			pstmt.setInt(4,number);  
		     return pstmt.executeUpdate(); 
			} catch (Exception e) {
				System.out.println(e);
			}finally {
				m3();
			}
			return -1; 
		
	}else {
		SQL= "update board set title=?,content = ?,location = ?,filename = ? where number =?";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,title);
			pstmt.setString(2,content);
			pstmt.setString(3,location);
			pstmt.setString(4,filename);
			pstmt.setInt(5,number);  
		     return pstmt.executeUpdate(); 
			} catch (Exception e) {
				System.out.println(e);
			}finally {
				m3();
			}
			return -1; 
	}
	
	}
	
	

public int delete(int number) {
	String SQL= "update board set available= 0 where number =?"; 
	try {
    pstmt = conn.prepareStatement(SQL);
	pstmt.setInt(1, number);  
	
     return pstmt.executeUpdate(); 
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		m3();
	}
	return -1;
}
	
}